
from PIL import Image, ImageDraw, ImageFont
import os

# Create a new image with WhatsApp green background
size = (192, 192)  # Larger size for better quality
img = Image.new('RGB', size, color='#25D366')  # WhatsApp green

# Create circular background
mask = Image.new('L', size, 0)
draw = ImageDraw.Draw(mask)
draw.ellipse((0, 0) + size, fill=255)

# Apply circular mask
img.putalpha(mask)

# Create a draw object
draw = ImageDraw.Draw(img)

# Text settings
text = "HT"
text_color = "white"

# Try to use a bold font
try:
    # Calculate font size (approximately 40% of image height)
    font_size = int(size[1] * 0.4)
    font = ImageFont.load_default()
    
    # Calculate text position to center it
    text_bbox = draw.textbbox((0, 0), text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    
    x = (size[0] - text_width) // 2
    y = (size[1] - text_height) // 2
    
    # Draw the text
    draw.text((x, y), text, fill=text_color, font=font)
    
    # Save in different sizes
    if not os.path.exists('static'):
        os.makedirs('static')
    
    img.save('static/favicon.ico', format='ICO', sizes=[(32, 32)])
    img.save('static/icon.png', format='PNG')
    
    # Save a larger version for Android
    img.save('static/launcher_icon.png', format='PNG')
    
except Exception as e:
    print(f"Error creating icon: {e}")
