
from flask import Flask, request, jsonify, render_template, send_file, redirect, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'mp4', 'mp3', 'doc', 'docx'}

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///messages.db'
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Change this to a secure secret key
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    contact = db.Column(db.String(100), unique=True, nullable=False)
    contact_type = db.Column(db.String(10), nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(500), nullable=True)
    sender = db.Column(db.String(100), nullable=False)
    contact = db.Column(db.String(100), nullable=False)  # Phone or email
    contact_type = db.Column(db.String(10), nullable=False)  # "phone" or "email"
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_synced = db.Column(db.Boolean, default=False)
    file_path = db.Column(db.String(500), nullable=True)
    file_type = db.Column(db.String(50), nullable=True)

with app.app_context():
    db.create_all()

@app.route('/')
def home():
    if 'user_id' not in session:
        return redirect('/auth')
    return redirect('/chat')

@app.route('/auth')
def auth():
    return render_template('auth.html')

@app.route('/chat')
def chat():
    if 'user_id' not in session:
        return redirect('/auth')
    return render_template('index.html')

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    contact = data.get('contact')
    contact_type = data.get('contact_type')
    password = data.get('password')
    
    if User.query.filter_by(contact=contact).first():
        return jsonify({'success': False, 'message': 'User already exists'})
    
    user = User(
        contact=contact,
        contact_type=contact_type,
        password_hash=generate_password_hash(password)
    )
    db.session.add(user)
    db.session.commit()
    
    session['user_id'] = user.id
    return jsonify({'success': True})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    contact = data.get('contact')
    password = data.get('password')
    
    user = User.query.filter_by(contact=contact).first()
    if user and check_password_hash(user.password_hash, password):
        session['user_id'] = user.id
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'message': 'Invalid credentials'})

@app.route('/api/messages', methods=['GET'])
def get_messages():
    messages = Message.query.order_by(Message.timestamp.desc()).all()
    return jsonify([{
        'id': msg.id,
        'content': msg.content,
        'sender': msg.sender,
        'timestamp': msg.timestamp.isoformat(),
        'is_synced': msg.is_synced
    } for msg in messages])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/api/messages', methods=['POST'])
def create_message():
    sender = request.form.get('sender')
    contact = request.form.get('contact')
    contact_type = request.form.get('contact_type')
    content = request.form.get('content', '')
    file = request.files.get('file')
    
    message = Message(
        sender=sender,
        contact=contact,
        contact_type=contact_type,
        content=content
    )
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(file_path)
        message.file_path = filename
        message.file_type = filename.rsplit('.', 1)[1].lower()
    
    db.session.add(message)
    db.session.commit()
    
    return jsonify({
        'id': message.id,
        'content': message.content,
        'sender': message.sender,
        'timestamp': message.timestamp.isoformat(),
        'is_synced': message.is_synced,
        'file_path': message.file_path,
        'file_type': message.file_type
    })

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_file(os.path.join(UPLOAD_FOLDER, filename))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
