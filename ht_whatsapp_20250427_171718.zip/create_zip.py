
import os
import zipfile
from datetime import datetime

def create_zip():
    # Get current timestamp for the filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    zip_filename = f'ht_whatsapp_{timestamp}.zip'
    
    # Create a zip file
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Walk through all directories
        for root, dirs, files in os.walk('.'):
            # Skip certain directories
            if any(x in root for x in ['.git', '__pycache__', 'venv']):
                continue
            
            for file in files:
                # Skip the zip file itself and certain file types
                if file.endswith('.zip') or file == '.replit' or file == 'replit.nix':
                    continue
                    
                file_path = os.path.join(root, file)
                # Add file to zip with relative path
                zipf.write(file_path)
    
    return zip_filename

if __name__ == '__main__':
    zip_file = create_zip()
    print(f'Created zip file: {zip_file}')
